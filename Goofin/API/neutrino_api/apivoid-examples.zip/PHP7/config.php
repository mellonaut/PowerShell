<?php

// Disable error reporting for ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED
@error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Disable printing of errors on the screen
@ini_set('display_errors', '0');

// Array with APIVoid settings
$_apivoid = array(

    // Enter your API key for APIVoid - https://www.apivoid.com/
    "key" => "",
	
);

?>